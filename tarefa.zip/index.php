<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>

  <?php
  include "referencias.php";
  ?>
</head>

<body>
  <main class="bg-light">


          <div class="item bg-gradient">
            <a href="tarefa_marcar.php">Marcar tarefa</a>
          </div>
          <div class="item bg-gradient">
            <a href="tarefa_listar.php">Listar tarefas</a>
          </div>
          <div class="item bg-gradient">
            <a href="tarefa_pesquisar.php">Pesquisar tarefas</a>
          </div>
    

  </main>

</body>

</html>